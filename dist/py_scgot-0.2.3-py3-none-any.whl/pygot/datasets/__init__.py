from ._datasets import *

__all__ = [
    'synthetic'
]